#!/bin/bash

for DB in mod_hpcdb mod_shredder modw
do
    echo "GRANT ALL ON $DB.* to '$MARIADB_USER'@'%';" | mysql -uroot
done

echo "FLUSH PRIVILEGES;" | mysql -uroot
